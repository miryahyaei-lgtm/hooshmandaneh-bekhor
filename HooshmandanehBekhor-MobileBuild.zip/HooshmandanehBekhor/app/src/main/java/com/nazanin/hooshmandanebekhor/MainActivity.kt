package com.nazanin.hooshmandanebekhor

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val green = Color(0xFF246B52)
private val pale = Color(0xFFEAF4EE)
private val ink = Color(0xFF24352D)
private val muted = Color(0xFF68776F)

data class Group(val name:String, val emoji:String, val intro:String)
data class Food(val name:String, val emoji:String, val nutrients:String, val why:String, val caution:String)

val groups = listOf(
    Group("کودکان زیر ۵ سال","🧸","در این سن، تنوع غذایی، آهن، چربی‌های مفید و بافت ایمن غذا اهمیت دارند. نیازهای نوزادان زیر یک سال ویژه است."),
    Group("کودکان ۵ تا ۱۲ سال","🎒","وعده‌های متنوع و منظم به تأمین انرژی و مواد مغذی مورد نیاز رشد کمک می‌کنند."),
    Group("نوجوانان ۱۳ تا ۱۸ سال","🚴","در دوران رشد سریع، دریافت کافی انرژی، پروتئین، آهن و کلسیم اهمیت دارد."),
    Group("بزرگسالان ۱۹ تا ۵۹ سال","🌿","الگوی غذایی متنوع با سبزی، میوه، غلات کامل و منابع پروتئین به سلامت عمومی کمک می‌کند."),
    Group("۶۰ سال به بالا","🌻","توجه به پروتئین، فیبر، کلسیم، ویتامین D، آب کافی و شرایط جویدن و بلع مهم است.")
)
val foodList = listOf(
    Food("عدس","🫘","پروتئین گیاهی، فیبر، فولات و آهن","عدس به تأمین پروتئین و فیبر کمک می‌کند. آهن گیاهی آن بهتر است همراه منبع ویتامین C مثل گوجه‌فرنگی مصرف شود.","کاملاً بپزید و برای خردسالان متناسب با توان جویدن له یا نرم کنید."),
    Food("ماست ساده","🥣","پروتئین و کلسیم","ماست ساده می‌تواند به دریافت کلسیم و پروتئین کمک کند؛ نوع بدون شکر افزوده را انتخاب کنید.","حساسیت به شیر یا عدم تحمل لاکتوز را در نظر بگیرید. شیر گاو جایگزین شیر مادر یا شیرخشک برای نوزاد نیست."),
    Food("تخم‌مرغ","🥚","پروتئین باکیفیت، کولین و ویتامین B12","تخم‌مرغ منبع پروتئین و چند ریزمغذی است و می‌تواند بخشی از الگوی غذایی متنوع باشد.","کاملاً بپزید. در صورت سابقه حساسیت، از متخصص سلامت راهنمایی بگیرید."),
    Food("جو دوسر","🥣","فیبر محلول و کربوهیدرات","فیبر محلول جو دوسر می‌تواند به سلامت قلب و عملکرد دستگاه گوارش کمک کند.","نوع ساده و کم‌شکر را انتخاب کنید و بافت آن را متناسب با سن آماده کنید."),
    Food("گردو","🌰","چربی‌های غیراشباع و امگا ۳ گیاهی","گردو دارای چربی‌های غیراشباع و اسید چرب ALA است.","آجیل کامل برای خردسالان خطر خفگی دارد؛ حساسیت به مغزها را هم در نظر بگیرید."),
    Food("سبزی‌های برگ‌سبز","🥬","فولات، ویتامین K و فیبر","این سبزی‌ها به تنوع دریافت ویتامین‌ها، مواد معدنی و فیبر کمک می‌کنند.","افراد مصرف‌کننده وارفارین درباره ثبات دریافت ویتامین K با پزشک مشورت کنند."),
    Food("ماهی","🐟","پروتئین و در برخی گونه‌ها امگا ۳","ماهی منبع پروتئین است و ماهی‌های چرب حاوی اسیدهای چرب امگا ۳ هستند.","نوع کم‌جیوه انتخاب و استخوان‌ها را جدا کنید؛ برای بارداری و کودکی راهنمای رسمی انتخاب ماهی مهم است.")
)

class MainActivity: ComponentActivity() {
    override fun onCreate(savedInstanceState:Bundle?) { super.onCreate(savedInstanceState); setContent { App() } }
}

@Composable fun App() {
    var group by remember { mutableStateOf<Group?>(null) }
    var food by remember { mutableStateOf<Food?>(null) }
    var search by remember { mutableStateOf("") }
    MaterialTheme(colorScheme = lightColorScheme(primary=green, background=Color(0xFFFAFCF9))) {
        Surface(Modifier.fillMaxSize(), color=Color(0xFFFAFCF9)) {
            when {
                food != null -> Detail(food!!, { food=null })
                group != null -> GroupPage(group!!, search, {search=it}, {group=null;search=""}, {food=it})
                else -> Home { group=it }
            }
        }
    }
}

@Composable fun Top(title:String, subtitle:String, back:(()->Unit)?=null) {
    Column(Modifier.fillMaxWidth().padding(20.dp)) {
        if(back!=null) Text("‹  بازگشت", Modifier.clickable { back() }, color=green, fontSize=14.sp)
        Spacer(Modifier.height(8.dp))
        Text("🥗  $title", fontSize=23.sp, fontWeight=FontWeight.Bold, color=ink)
        Text(subtitle, color=muted, fontSize=13.sp)
    }
}

@Composable fun Home(onPick:(Group)->Unit) {
    Column {
        Top("هوشمندانه بخور","راهنمای ساده تغذیه در سنین مختلف")
        Card(Modifier.fillMaxWidth().padding(horizontal=18.dp), colors=CardDefaults.cardColors(containerColor=pale), shape=RoundedCornerShape(20.dp)) {
            Column(Modifier.padding(18.dp)) {
                Text("غذای بهتر، انتخاب آگاهانه‌تر", color=green, fontSize=19.sp, fontWeight=FontWeight.Bold)
                Text("گروه سنی را انتخاب کن تا با نیازهای تغذیه‌ای و خوراکی‌های مفید آن دوره آشنا شوی.", color=ink, modifier=Modifier.padding(top=8.dp), lineHeight=23.sp)
            }
        }
        Text("برای چه گروه سنی اطلاعات می‌خواهی؟", Modifier.padding(20.dp), fontWeight=FontWeight.Bold, color=ink)
        LazyColumn(contentPadding=PaddingValues(horizontal=18.dp, vertical=4.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            items(groups) { g ->
                Card(Modifier.fillMaxWidth().clickable { onPick(g) }, shape=RoundedCornerShape(16.dp), colors=CardDefaults.cardColors(containerColor=Color.White)) {
                    Row(Modifier.padding(17.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(g.emoji, fontSize=29.sp); Spacer(Modifier.width(14.dp))
                        Text(g.name, Modifier.weight(1f), fontWeight=FontWeight.Bold, color=ink)
                        Text("‹", color=green, fontSize=26.sp)
                    }
                }
            }
        }
        Text("اطلاعات آموزشی است و جایگزین توصیه پزشک یا متخصص تغذیه نیست.", Modifier.fillMaxWidth().padding(10.dp), textAlign=TextAlign.Center, color=muted, fontSize=10.sp)
    }
}

@Composable fun GroupPage(g:Group, q:String, onQ:(String)->Unit, back:()->Unit, pick:(Food)->Unit) {
    val list = foodList.filter { q.isBlank() || it.name.contains(q.trim(), true) }
    Column {
        Top(g.name,"راهنمای گروه سنی",back)
        Card(Modifier.fillMaxWidth().padding(horizontal=18.dp), colors=CardDefaults.cardColors(containerColor=pale), shape=RoundedCornerShape(16.dp)) {
            Text(g.intro, Modifier.padding(16.dp), color=ink, lineHeight=22.sp)
        }
        OutlinedTextField(q,onQ,Modifier.fillMaxWidth().padding(18.dp),placeholder={Text("جست‌وجوی ماده غذایی")},singleLine=true,shape=RoundedCornerShape(14.dp))
        Text("با این خوراکی‌ها آشنا شو", Modifier.padding(horizontal=20.dp), color=ink, fontWeight=FontWeight.Bold)
        LazyColumn(contentPadding=PaddingValues(18.dp), verticalArrangement=Arrangement.spacedBy(9.dp)) {
            items(list) { f ->
                Card(Modifier.fillMaxWidth().clickable { pick(f) }, colors=CardDefaults.cardColors(containerColor=Color.White), shape=RoundedCornerShape(15.dp)) {
                    Row(Modifier.padding(15.dp), verticalAlignment=Alignment.CenterVertically) {
                        Text(f.emoji,fontSize=28.sp); Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(f.name,fontWeight=FontWeight.Bold,color=ink); Text(f.nutrients,fontSize=12.sp,color=muted) }
                        Text("‹",color=green,fontSize=24.sp)
                    }
                }
            }
        }
    }
}

@Composable fun Detail(f:Food, back:()->Unit) {
    Column {
        Top("درباره ${f.name}","ارزش غذایی و نکات کاربردی",back)
        LazyColumn(contentPadding=PaddingValues(horizontal=18.dp, vertical=6.dp), verticalArrangement=Arrangement.spacedBy(13.dp)) {
            item {
                Card(Modifier.fillMaxWidth(), colors=CardDefaults.cardColors(containerColor=pale), shape=RoundedCornerShape(18.dp)) {
                    Column(Modifier.fillMaxWidth().padding(20.dp), horizontalAlignment=Alignment.CenterHorizontally) {
                        Text(f.emoji,fontSize=48.sp); Text(f.name,fontSize=22.sp,color=green,fontWeight=FontWeight.Bold); Text(f.nutrients,color=muted,textAlign=TextAlign.Center)
                    }
                }
            }
            item { Info("چرا می‌تواند مفید باشد؟",f.why) }
            item { Info("نکته مهم",f.caution) }
            item { Info("منابع پیشنهادی برای مطالعه","سازمان جهانی بهداشت (WHO) – راهنمای تغذیه سالم\nNHS – راهنمای تغذیه متناسب با سن\nHarvard T.H. Chan School of Public Health – The Nutrition Source\nاین نسخه اولیه است و محتوای آن هنوز بازبینی تخصصی نشده است.") }
            item { Text("مفید بودن یک ماده غذایی به معنی مناسب بودن آن برای همه افراد یا مصرف نامحدود نیست. حساسیت‌ها، بیماری‌ها، داروها و نیازهای فردی اهمیت دارند.", color=muted, fontSize=12.sp, lineHeight=19.sp) }
        }
    }
}
@Composable fun Info(title:String,body:String) {
    Card(Modifier.fillMaxWidth(),colors=CardDefaults.cardColors(containerColor=Color.White),shape=RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(17.dp)) { Text(title,color=green,fontWeight=FontWeight.Bold,fontSize=16.sp); Spacer(Modifier.height(7.dp)); Text(body,color=ink,lineHeight=22.sp,fontSize=14.sp) }
    }
}
